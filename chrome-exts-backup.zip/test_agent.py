#!/usr/bin/env python3
"""
Quick test to verify agent receives data from Chrome
"""

import asyncio
import json
import websockets
import requests


async def test_agent_receives_data():
    """Test that agent can receive tab data from Chrome"""
    print("=" * 60)
    print("🧪 Testing Agent Integration")
    print("=" * 60)

    # Step 1: Check server
    print("\n1. Checking relay server...")
    try:
        response = requests.get("http://127.0.0.1:18792/health", timeout=2)
        health = response.json()
        print(f"   ✓ Server running: {health['status']}")
        print(f"   ✓ Extension connected: {health['extension_connected']}")
    except:
        print("   ✗ Server not running. Start with: python3 relay_server.py")
        return

    # Step 2: Check current tabs in database
    print("\n2. Checking database...")
    try:
        response = requests.get("http://127.0.0.1:18792/tabs", timeout=2)
        tabs = response.json()
        print(f"   ✓ Database has {len(tabs)} tabs")
        if tabs:
            print(f"   ✓ Latest: {tabs[0].get('title', 'Unknown')[:50]}")
    except Exception as e:
        print(f"   ✗ Error: {e}")

    # Step 3: Connect to WebSocket
    print("\n3. Testing WebSocket connection...")
    print("   (Connect and wait for Chrome extension to send data)")
    print("   (Click the Chrome extension icon to trigger collection)\n")

    try:
        async with websockets.connect("ws://127.0.0.1:18792/client") as ws:
            print("   ✓ Connected to WebSocket")
            print("   ⏳ Waiting for data from Chrome (30 seconds)...")
            print("   💡 Click the Chrome extension icon now!\n")

            # Wait for messages with timeout
            received_data = False

            try:
                while True:
                    message = await asyncio.wait_for(ws.recv(), timeout=30.0)
                    data = json.loads(message)

                    msg_type = data.get("type")
                    msg_data = data.get("data", {})

                    if msg_type == "tabDataQuick":
                        tabs = msg_data.get("tabs", [])
                        print(f"   📥 RECEIVED: {len(tabs)} tabs!")
                        for i, tab in enumerate(tabs[:3], 1):
                            print(f"      {i}. {tab.get('title', 'No title')[:50]}")
                        received_data = True

                    elif msg_type == "tabDataDeep":
                        tab = msg_data.get("tab", {})
                        html_size = len(tab.get("html", ""))
                        print(
                            f"   📄 RECEIVED: Deep content for '{tab.get('title', 'Unknown')[:40]}'"
                        )
                        print(f"      HTML size: {html_size} characters")
                        received_data = True

                    elif msg_type == "complete":
                        print(
                            f"   ✓ Collection complete: {msg_data.get('totalTabs')} tabs"
                        )

                        if received_data:
                            print("\n" + "=" * 60)
                            print("✅ SUCCESS! Agent is receiving data from Chrome!")
                            print("=" * 60)
                            print("\nNext steps:")
                            print("  1. Run: python3 auto_agent.py")
                            print(
                                "  2. Or integrate simple_integration.py into your agent"
                            )
                        break

            except asyncio.TimeoutError:
                print("\n   ⏱ Timeout - No data received in 30 seconds")
                print("   💡 Make sure to click the Chrome extension icon!")

    except Exception as e:
        print(f"   ✗ WebSocket error: {e}")


if __name__ == "__main__":
    try:
        asyncio.run(test_agent_receives_data())
    except KeyboardInterrupt:
        print("\n\nTest stopped by user")
