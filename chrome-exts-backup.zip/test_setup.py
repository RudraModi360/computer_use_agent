#!/usr/bin/env python3
"""
Quick test script to verify the Chrome Tab Tracker setup
"""

import requests
import sys
import time


def test_relay_server():
    """Test if relay server is running"""
    try:
        response = requests.get("http://127.0.0.1:18792/health", timeout=2)
        if response.status_code == 200:
            data = response.json()
            print("✓ Relay server is running")
            print(f"  Status: {data.get('status')}")
            print(f"  Extension connected: {data.get('extension_connected')}")
            return True
        else:
            print("✗ Relay server returned error")
            return False
    except requests.exceptions.ConnectionError:
        print("✗ Relay server not running")
        print("  Start it with: python relay_server.py")
        return False
    except Exception as e:
        print(f"✗ Error: {e}")
        return False


def test_database():
    """Test database connectivity"""
    try:
        import sqlite3

        conn = sqlite3.connect("chrome_corpus.db")
        cursor = conn.cursor()

        # Check tables
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]

        print("✓ Database initialized")
        print(f"  Tables: {', '.join(tables)}")

        # Count records
        for table in ["tabs", "tab_content", "tab_events"]:
            if table in tables:
                cursor.execute(f"SELECT COUNT(*) FROM {table}")
                count = cursor.fetchone()[0]
                print(f"  {table}: {count} records")

        conn.close()
        return True
    except Exception as e:
        print(f"✗ Database error: {e}")
        return False


def main():
    print("Chrome Tab Tracker - Setup Test")
    print("=" * 40)
    print()

    # Test relay server
    relay_ok = test_relay_server()
    print()

    # Test database
    db_ok = test_database()
    print()

    # Summary
    print("Summary")
    print("=" * 40)
    if relay_ok and db_ok:
        print("✓ All systems ready!")
        print()
        print("Next: Load the extension in Chrome and click it to start collecting")
        return 0
    else:
        print("✗ Some components need attention")
        if not relay_ok:
            print("  - Start relay server: python relay_server.py")
        if not db_ok:
            print("  - Database will be created automatically when server starts")
        return 1


if __name__ == "__main__":
    sys.exit(main())
